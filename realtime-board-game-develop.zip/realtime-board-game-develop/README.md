# realtime-board-game

A realtime board game that utilises firebase and javaFx. This was coursework for Leiden University of Applied sciences.
