package nl.hsleiden.ipsene.exceptions;

public class OverdrawException extends Exception {
  public OverdrawException(String message) {
    super(message);
  }
}
