package nl.hsleiden.ipsene.interfaces;

public interface View {
  void update();
}
